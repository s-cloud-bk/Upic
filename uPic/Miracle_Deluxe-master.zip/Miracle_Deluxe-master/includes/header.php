    <header>
      <nav class="nav">
        <div class="nav-mobile small-screen">
          <div class="nav-mobile-btn">
            <div><button id="nav-mobile-open"><i class="iconfont icon-list"></i></button></div>
            <div class="nav-mobile-capital"><?php if(Helper::options()->blogName) $name=Helper::options()->blogName;
                  else $name=Helper::options()->title;
            echo '<a href="'.Helper::options()->siteUrl.'">'.$name.'</a>'; ?></div>
            <div><button id="nav-mobile-more"><i class="iconfont icon-block"></i></button></div>
          </div>
        </div>
        <div class="body-container nav-regular large-screen">
          <?php Contents::Nav($this);
          Contents::NavIcons($this); ?>
        </div>
      </nav>
      <div class="nav-mobile-panel small-screen hidden">
        <?php Contents::Nav($this, 'mobile'); ?>
      </div>
      <div class="nav-mobile-bar small-screen hidden">
        <?php Contents::NavIcons($this, 'mobile'); ?>
      </div>
      <div class="nav-search hidden">
        <form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
          <input type="text" id="s" name="s" class="text" placeholder="<?php _e('输入关键字搜索'); ?>" />
          <button type="submit" class="submit"><?php _e('搜索'); ?></button>
          <button class="small-screen" id="nav-search-close"><i class="iconfont icon-x"></i></button>
        </form>
      </div>
      <?php $this->options->headerCustom(); ?>
    </header>
    <div id="pjax-container">
      <div class="banner">
      <img src="<?php if($this->fields->banner && $this->is('single')):
         $this->fields->banner(); 
         $banner_bg_mask=true;
      elseif($this->options->bannerURL): 
         $this->options->bannerURL(); 
         $banner_bg_mask=true;
      endif; ?>" class="banner-img">
        <div class="banner-mask<?php 
        if(!$banner_bg_mask) echo ' no-bg'; 
        ?>">
          <div class="main-container">
            <div class="banner-content<?php if($banner_bg_mask) echo ' theme-dark'; ?>">
              <?php if($this->is('index')){ ?>
              <h1 class="banner-title"><?php echo Utils::blogInfo('name'); ?></h1>
              <p><?php echo Utils::blogInfo('des'); ?></p>
              <?php }else{ ?>
              <h1 class="banner-title archive-title"><?php $this->archiveTitle($GLOBALS['lang_archive']['archive_title'], '', ''); ?></h1>
              <?php if($this->is('single')): ?><p class="banner-meta">
                <?php if($this->is('post')): ?><i class="iconfont icon-block"></i> <span class="banner-meta-category"><?php $this->category(); ?></span>&nbsp;&nbsp;<?php endif; ?>
                <i class="iconfont icon-clock-o"></i> <?php $this->date(); ?>&nbsp;&nbsp;
                <?php if(!$_SESSION['archive'])://如果不是归档页面才输出 ?><i class="iconfont icon-comments"></i> <?php $this->commentsNum('0', '1', '%d'); ?>&nbsp;&nbsp;<?php endif; $_SESSION['archive']=''; ?>
                <i class="iconfont icon-view"></i> <?php echo Func::postViews($this); ?>
              </p><?php endif; ?>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
    