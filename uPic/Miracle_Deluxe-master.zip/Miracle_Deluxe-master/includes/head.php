<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; 
if($this->options->compressHTML==1) ob_start(); //ob 截取开始 ?>
<!DOCTYPE html>
<html lang="<?php $this->options->lang_(); ?>">
  <head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="renderer" content="webkit">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title><?php Contents::title($this); ?></title><?php
      //meta
      if($this->is('single')){
        $link=$this->permalink;
        if($this->fields->banner){
          $banner=$this->fields->banner;
        }
        elseif($this->options->bannerURL){
          $banner=$this->options->bannerURL;
        }
        else{
          $banner=Utils::getFavicon();
        }
      }
      else{
        $link=$this->siteUrl;
          $banner= $this->options->bannerURL ? $this->options->bannerURL : Utils::getFavicon();
      }
      //description
      function echoDes($archive, $experts) {
        if($archive->is('single')&&$experts){
          $archive->experts(100);
        }else{
          Helper::options()->description();
        }
      }
    ?>
    <meta itemprop="name" content="<?php Contents::title($this); ?>"/>
    <meta itemprop="image" content="<?php Utils::getFavicon(); ?>" />
    <meta name="author" content="<?php $this->author(); ?>" />
    <meta name="description" content="<?php echoDes($this, $this->experts); ?>" />
    <meta property="og:title" content="<?php Contents::title($this); ?>" />
    <meta property="og:description" content="<?php echoDes($this, $this->experts); ?>" />
    <meta property="og:site_name" content="<?php Helper::options()->title(); ?>" />
    <meta property="og:type" content="<?php if($this->is('single')) echo 'article'; else echo 'website'; ?>" />
    <meta property="og:url" content="<?php echo $link; ?>" />
    <meta property="og:image" content="<?php echo $banner; ?>" />
    <meta property="article:published_time" content="<?php echo date('c', $this->created); ?>" />
    <meta property="article:modified_time" content="<?php echo date('c', $this->modified); ?>" />
    <meta name="twitter:title" content="<?php Contents::title($this); ?>" />
    <meta name="twitter:description" content="<?php echoDes($this, $this->experts); ?>" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:image" content="<?php echo $banner; ?>" />
    <!-- Favicon -->
    <link rel="icon" href="<?php echo Utils::getFavicon(); ?>">
    <!-- Font -->
    <link rel="stylesheet" href="https://at.alicdn.com/t/font_1165190_1djdjjwge4m.css" /><!-- iconfont -->
    <?php if($this->options->fontCDN!='0'): ?><link rel="stylesheet" href="<?php 
      if($this->options->fontCDN=='1'): $theme_font_url = "https://fonts.googleapis.com/css?family=Noto+Sans+SC:300|Noto+Serif+SC&display=swap";
      elseif($this->options->fontCDN=='2'): $theme_font_url = "https://fonts.loli.net/css?family=Noto+Sans+SC:300|Noto+Serif+SC&display=swap";
      else: $theme_font_url = $this->options->fontCustom;
      endif;
      echo $theme_font_url;
     ?>" /><?php endif; ?><!-- Font CDN -->
    <!-- css -->
    <?php Utils::Require('lib-css', array('normalize'), 'normalize'); ?>
    <?php Utils::Require('lib-css', array('gazeimg.min'), 'gazeimg'); ?>
    <?php Utils::Require('lib-css', array('nprogress'), 'nprogress'); ?>
    <?php Utils::Require('lib-css', array('hint.min'), 'hint'); ?>
    <?php Utils::Require('lib-css', array('textretty.min'), 'textretty'); ?>
    <?php Utils::Require('lib-css', array('owo.min'), 'owo'); ?>
    <?php Utils::Require('lib-css', array('codestyle'), 'highlight'); ?>
    <?php Utils::Require('lib-css', array('notyf.min'), 'notyf'); ?>
    <?php Utils::Require('css', array('miracle')); ?>
    <!-- 其他 -->
    <style><?php $this->options->CSSCustom(); ?></style>
    <?php $this->options->headCustom();
    $this->header('generator=&pingback=&xmlrpc=&wlw=&commentReply=&description=&antiSpam='); ?>
  </head>
  <body class="layout-<?php if($this->options->layout=='0'): echo 'classic';
  elseif($this->options->layout=='1'): echo 'roundish';
  elseif($this->options->layout=='2'): echo 'lively'; endif; ?>">
