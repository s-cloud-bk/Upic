<div class="main-container">
  <div class="post-body">
    <div class="post-content textretty tex-title-no-line"><?php $this->content(); ?></div>
    <div class="post-footer">
        <!-- footer -->
    </div>
  </div>
  <?php $this->need('includes/comments.php'); ?>
</div>