    </div>
    <footer>
	  <div class="footer">
		<div class="main-container">
		  <?php Contents::footer($this); ?>
		</div>
	  </div>
	  <!-- gotop -->
	  <button class="button-float gotop-button" id="gotop"><i class="iconfont icon-chevron-up"></i></button>
	  <!-- js -->
	  <?php Utils::Require('lib-js', array('jquery.min','pjax.jquery'), 'jquery'); ?>
	  <?php Utils::Require('lib-js', array('nprogress'), 'nprogress'); ?>
	  <?php Utils::Require('lib-js', array('gazeimg'), 'gazeimg'); ?>
	  <?php Utils::Require('lib-js', array('smoothscroll'), 'smoothScroll'); ?>
	  <?php Utils::Require('lib-js', array('owo.min'), 'owo'); ?>
	  <?php Utils::Require('lib-js', array('pangu.min'), 'pangu'); ?>
	  <?php Utils::Require('lib-js', array('notyf.min'), 'notyf'); ?>
	  <?php Utils::Require('lib-js', array('highlight','highlight-line-number'), 'highlight'); ?>
	  <!-- config -->
	  <!-- <nocompress> -->
	  <script>var siteurl='<?php $this->options->siteUrl(); ?>';
var loadPjax=<?php if($this->options->pjaxSwitch!='0'){echo 'true';}else{echo 'false';} ?>;
var beforePjax=function(){};var afterPjax=function(){<?php if(Utils::hasPlugin('Meting')): ?>loadMeting();<?php endif; $this->options->pjaxCallback(); ?>}
var owoJson='<?php Utils::indexTheme('assets/libs/owo/OwO.json'); ?>';
const __TYPECHO_ADMIN_DIR__=<?php echo __TYPECHO_ADMIN_DIR__; ?>;
</script><!-- </nocompress> -->
	  <!-- MIRACLE js -->
	  <?php Utils::Require('js', array('miracle-lib', 'miracle-front')); ?>
	  <!-- other -->
	  <script><?php $this->options->JSCustom(); ?></script>
	  <?php $this->footer();
	  $this->options->footerCodeCustom(); ?>
    </footer>
  </body>
</html>
<?php if($this->options->compressHTML==1) {
	$html_source = ob_get_contents(); //获取 ob 截取内容
	ob_clean(); print Contents::compressHtml($html_source); ob_end_flush(); //完成截取、压缩 HTML
} ?>