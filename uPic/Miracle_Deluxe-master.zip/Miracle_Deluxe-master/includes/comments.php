<?php if($this->options->commentSwitch=='1'): 
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$parameter = array(
   'parentId'      => $this->hidden ? 0 : $this->cid,
   'parentContent' => $this->row,
   'respondId'     => $this->respondId,
   'commentPage'   => $this->request->filter('int')->commentPage,
   'allowComment'  => $this->allow('comment')
);
$this->widget('Miracle_Comments_Archive', $parameter)->to($comments);

if(!$this->hidden):
  //如果允许评论
  if($this->allow('comment')):
?>
<div id="comments">
 <?php Miracle_Comments_Archive::replyScript($this); ?>
 <div id="<?php $this->respondId(); ?>" class="respond comment-box comment-box-id" data-commentUrl="<?php $this->commentUrl() ?>">
  <form method="post" action="<?php $this->commentUrl() ?>" id="comment-form" role="form">
    <?php if($this->user->hasLogin()): //如果登录 ?>
    <p class="col-md-12 comment-logined-sign"><?php gtecho('lang_comment','login_status_label'); ?> <a class="link-underline" href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>, <a class="link-underline" href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php gtecho('lang_comment','logout_btn'); ?></a></p>
    <?php else: //如果没登陆 ?>
    <div class="comment-input">
      <input type="text" name="author" id="author" class="text" placeholder="<?php gtecho('lang_comment','name'); ?>" value="<?php $this->remember('author'); ?>" required />
      <input type="email" name="mail" id="mail" class="text" placeholder="<?php gtecho('lang_comment','mail'); ?>" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?> />
      <input type="url" name="url" id="url" class="text" placeholder="<?php gtecho('lang_comment','url'); ?>" value="<?php $this->remember('url'); ?>"<?php if ($this->options->commentsRequireURL): ?> required<?php endif; ?> />
	</div>
    <?php endif;//评论内容 ?>
    <p>
      <textarea rows="8" name="text" id="textarea" class="OwO-textarea comment-textarea textarea" required ><?php $this->remember('text'); ?></textarea>
    </p>
	  <div class="comment-submit-box">
      <div title="OwO" class="OwO"></div>
      <div class="button-box">
	      <span class="cancel-comment-reply"><?php $comments->cancelReply(); ?></span>
        <button type="submit" class="button-circle comment-submit submit"><?php gtecho('lang_comment','comment_btn'); ?></button>
      </div>
    </div>
  </form>
</div>
  <?php endif;
  if($comments->have() && $this->fields->commentShow == 0){?>
  <div class="comment-list-body">
    <div class="comment-list-title">
      <h2 id="response"><?php gtaecho('lang_comment', 'comment_list_title', '<span>'.$this->commentsNum.'</span>') ?></h2>
    </div>
  <?php
         $comments->listComments(array(
          'before'        =>  '<div id="comments-list" class="comments-list">',
          'after'         =>  '</div>',
          'avatarSize'    =>  64,
          'dateFormat'    =>  'Y-m-d H:i'
         ));
      }
    $comments->pageNav('<span><<</span>', '<span>>></span>', 1, '...', 'wrapTag=div&wrapClass=comments-pagenav&prevClass=prev&nextClass=next'); 
    if($this->options->commentsAntiSpam) Miracle_Comments_Archive::AntiSpam($this); 

    endif;endif;
  ?></div></div><br>