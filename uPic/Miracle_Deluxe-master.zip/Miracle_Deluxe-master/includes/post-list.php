<div class="post-list main-container">
<?php while($this->next()): ?>
    <div class="post-item" role="article">
        <div class="container-fluid"><div class="row">
            <div class="col-md-6 post-banner-box">
			    <div class="post-banner">
				    <img src="<?php Utils::indexTheme('assets/img/bilibili.gif'); ?>" data-gisrc="<?php Contents::postBanner($this); ?>">
				</div>
			  </div>
			  <div class="col-md-6 post-item-content">
			    <a href="<?php $this->permalink(); ?>" class="post-link" title="<?php $this->title(); ?>">
				  <h1 class="post-title"><?php $this->sticky(); ?><?php $this->title(); ?></h1>
				</a>
				<p class="post-excerpt"><?php if($this->fields->excerpt) {
				    echo $this->fields->excerpt;
				  }else{
					echo $this->excerpt(130);
				  }
				  ?></p>
				<p class="post-meta"><i class="iconfont icon-block"></i> <?php $this->category(','); ?>&emsp;<i class="iconfont icon-comments"></i> <?php $this->commentsNum('0', '1', '%d'); ?>&emsp;<i class="iconfont icon-clock"></i> <?php $this->date(); ?></p>
				<p class="post-button-box large-screen"><a href="<?php $this->permalink(); ?>" class="button-circle post-button"><?php gtecho('lang_post','read_more'); ?></a></p>
			  </div>
			</div></div>
		  </div>
<?php endwhile; ?>
</div>
<!-- 文章分页 -->
<div class="post-pagenav main-container">
  <span class="post-pagenav-left"><?php $this->pageLink('<i class="iconfont icon-chevron-left"></i>'); ?></span>
  <span class="post-pagenav-right"><?php $this->pageLink('<i class="iconfont icon-chevron-right"></i>','next'); ?></span>
</div>