<?php
/**
 * Language.php
 * 多语言
 */

if(Helper::options()->lang_ && Helper::options()->lang_!=''){
    $lang=Helper::options()->lang_;
}else{
    $lang='zh-cn';
}
require_once('lang/'.$lang.'.php');

//快速获取对应语言文本
function gt($a, $b) {
    return $GLOBALS[$a][$b];
}
function gtecho($a, $b) {
    echo $GLOBALS[$a][$b];
}
//有参数的文本获取
function gta($a, $b, $c) {
    $content = str_replace('%s', $c, $GLOBALS[$a][$b]);
    return $content;
}
function gtaecho($a, $b, $c) {
    $content = str_replace('%s', $c, $GLOBALS[$a][$b]);
    echo $content;
}