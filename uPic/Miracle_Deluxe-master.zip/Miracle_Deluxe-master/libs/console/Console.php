<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 控制台
 * by Eltrac
 */

Class Console
{
    /**
     * Post
     */
    public static function POST($remote_server, $post_string) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $remote_server);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'domain=' . $post_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "jb51.net's CURL Example beta");
        $data = curl_exec($ch);
        curl_close($ch);
      
        return $data;
    }
}
$post = Console::POST('https://www.miracles.pro/action/user_log.php', $_SERVER['SERVER_NAME']);
print_r($post);