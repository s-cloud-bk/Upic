<?php
/**
 * Config.php
 * 主题配置
 */

require_once('Console.php');//后台核心
require_once('Form.php');
function themeConfig($form) {
    /**
     * 设置备份
     */
    $db = Typecho_Db::get();
$sjdq=$db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:Miracles'));
$ysj = $sjdq['value'];
if(isset($_POST['type']))
{ 
if($_POST["type"]=="备份模板数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:Miracles'))){
$update = $db->update('table.options')->rows(array('value'=>$ysj))->where('name = ?', 'theme:Miracles');
$updateRows= $db->query($update);
echo '<div class="miracle-alert alert-success">备份已更新，请等待自动刷新！如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}else{
if($ysj){
     $insert = $db->insert('table.options')
    ->rows(array('name' => 'theme:Miracles','user' => '0','value' => $ysj));
     $insertId = $db->query($insert);
echo '<div class="miracle-alert alert-success">备份完成，请等待自动刷新！如果等不到请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}
}
        }
if($_POST["type"]=="还原模板数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:Miracles'))){
$sjdub=$db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:Miracles'));
$bsj = $sjdub['value'];
$update = $db->update('table.options')->rows(array('value'=>$bsj))->where('name = ?', 'theme:Miracles');
$updateRows= $db->query($update);
echo '<div class="miracle-alert alert-success">设置恢复成功，两秒后会自动跳转，若浏览器无反应请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2000);</script>
<?php
}else{
echo '<div class="miracle-alert alert-error">未在数据库中找到备份，无法恢复</div>';
}
}
if($_POST["type"]=="删除备份数据"){
if($db->fetchRow($db->select()->from ('table.options')->where ('name = ?', 'theme:Miracles'))){
$delete = $db->delete('table.options')->where ('name = ?', 'theme:Miracles');
$deletedRows = $db->query($delete);
echo '<div class="miracle-alert alert-success">删除成功，两秒后会自动跳转，若浏览器无反应请点击';
?>    
<a href="<?php Helper::options()->adminUrl('options-theme.php'); ?>">这里</a></div>
<script language="JavaScript">window.setTimeout("location=\'<?php Helper::options()->adminUrl('options-theme.php'); ?>\'", 2500);</script>
<?php
}else{
echo '<div class="miracle-alert alert-warning">未在数据库中找到备份，不用删除</div>';
}
}
    }

    /**
     * 布局
     */
    //引入 css
    echo '<link rel="stylesheet" href="';
    Helper::options()->themeUrl('assets/css/miracle-console.css');
    echo '">
    <link rel="stylesheet" href="https://at.alicdn.com/t/font_2016903_x15z70fthdj.css">';
    //顶部设置面板
    echo '  <div class="miracle-panel-item top">
        <h1><i class="iconfont iconconfettipopper miracle-logo"></i> Miracle 设置面板</h1>
        <p class="miracle-panel-notice">这里是公告位。<button id="close-notice"><i style="color:gray" class="iconfont iconcc-close-crude"></i></button></p>';
    if (!extension_loaded('curl')) echo '<p style="color:red;font-weight:bolder">您未开启 cURL 拓展，某些功能无法正常使用</p>';
    echo '<p class="miracle-info">
            当前版本：'._THEME_VERSION_.' | 最新版本：<span id="latest-version">Fetching...</span>
        </p>
        <p>
        <button type="submit" id="open-all" class="btn btn-s"><span><i class="iconfont iconfolder1"></i></span>展开所有设置</button>
        <button type="submit" id="close-all" class="btn btn-s"><span><i class="iconfont iconfolder"></i></span>折叠所有设置</button>
            <hr>
            <form class="protected" action="?Miraclesbf" method="post">
                <label>设置备份：</label>
                <input type="submit" name="type" class="btn btn-s backup-btn" value="备份模板数据" />&nbsp;&nbsp;
                <input type="submit" name="type" class="btn btn-s backup-btn" value="还原模板数据" />&nbsp;&nbsp;
                <input type="submit" name="type" class="btn btn-s backup-btn" value="删除备份数据" />
            </form>
        </p>
    </div>';

    /**
     * 设置项
     */
    /* == Information == */
    $form->addItem(new Contain('<div class="miracle-panel">'));
    $form->addItem(new Title('<i class="iconfont iconinfo miracle-item-icon"></i> 信息','站点信息 全站公告'));

    $blogName = new Text("blogName", NULL, NULL, "博客名称","填入你博客的名称，不同于 Typecho 基础设置中的站点名，这个名称主要用于显示而不会输出在头部");
    $form->addInput($blogName);
    $blogDes = new Text("blogDes", NULL, NULL, "博客描述","用一句话介绍你的博客，不同于 Typecho 基础设置中的站点描述，这个名称主要用于显示而不会输出在头部");
    $form->addInput($blogDes);
    $blogAuthor = new Text("blogAuthor", NULL, NULL, "博主名字","输入博客主要维护者的名字。");
    $form->addInput($blogAuthor);

    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    /* == /Information == */

    /* == Display == */
    $form->addItem(new Contain('<div class="miracle-panel">'));
    $form->addItem(new Title('<i class="iconfont icondisplay miracle-item-icon"></i> 显示','布局 首页大图 导航栏 Favicon'));

    $layout = new Radio('layout',array(
        '0' => '<img title="经典（Miracles.1.0）" style="width:8.5em" src="'.Helper::options()->themeUrl.'/assets/img/admin/layout-classic.png">',
        '1' => '<img title="圆润" style="width:8.5em" src="'.Helper::options()->themeUrl.'/assets/img/admin/layout-round.png">',
        '2' => '<img title="活泼" style="width:8.5em" src="'.Helper::options()->themeUrl.'/assets/img/admin/layout-active.png">',
        '3' => '<img title="画册" style="width:8.5em" src="'.Helper::options()->themeUrl.'/assets/img/admin/layout-album.png">'
    ),'0',_t('基本布局'),_t('选择一个你喜欢的页面布局方式'));
    $form->addInput($layout);

    $bannerURL = new Text("bannerURL", NULL, NULL, "首页大图 URL","在这里填入一个图片的 URL，会将这张图片展示在首页的顶部，如果你不需要请留空。");
    $form->addInput($bannerURL);
    $bannerColor = new Select('bannerColor',array(
        '0' => '经典灰',
        '1' => '少女粉',
        '2' => '清澈蓝',
        '3' => '低调黑',
        '4' => '活跃红',
        '5' => '环保绿',
        '6' => '基佬紫'
    ),'0',_t('主题色'),_t('选择一个颜色，作为主题主要的强调色，即主题色，同时也会在首页大图没有图片时作为其背景图。'));
    $form->addInput($bannerColor);

    $navContent = new Textarea("navContent", NULL, NULL, "导航栏","根据 WIKI，按照 JSON 格式书写，留空则显示默认的导航栏内容");
    $form->addInput($navContent);

    $favicon = new Text("favicon", NULL, NULL, "Favicon","在这里填入一个图片的 URL，会将这张图片作为 Favicon 展示在浏览器标签页上");
    $form->addInput($favicon);

    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    /* == /Display == */

    /* == Improvement == */
    $form->addItem(new Contain('<div class="miracle-panel" miracle-panel="">'));
    $form->addItem(new Title('<i class="iconfont iconDiagramArrowUp miracle-item-icon"></i> 优化','Pjax、HTML 压缩、评论无刷新、懒加载'));

    $pjaxSwitch = new Select('pjaxSwitch',array(
        '0' => '关',
        '1' => '开',
    ),'1',_t('Pjax 开关'),_t('选择是否开始 Pjax 预加载，开启后有助于提升页面速度和用户体验，但可能会导致未知错误'));
    $form->addInput($pjaxSwitch);
    $pjaxCallback = new Textarea("pjaxCallback", NULL, NULL, "Pjax 回调/重载函数","写入 js 代码，会在 pjax 完成页面加载后执行，通常用于重载一些需要处理新内容的 JS 脚本。如果你不知道这是什么，请留空");
    $form->addInput($pjaxCallback);

    $compressHTML = new Select('compressHTML',array(
        '0' => '关',
        '1' => '开',
    ),'1',_t('HTML 压缩'),_t('选择是否开启 HTML 压缩，开启后有助于提高页面传输速度'));
    $form->addInput($compressHTML);

    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    /* == /Improvement == */

    /* == Super == */
    $form->addItem(new Contain('<div class="miracle-panel" miracle-panel="">'));
    $form->addItem(new Title('<i class="iconfont iconsetting miracle-item-icon"></i> 高级','字体 CDN、Gravatar CDN、TimThumb、前台语言'));

    //字体 CDN
    $fontCDN = new Select('fontCDN',array(
        '0' => '关闭',
        '1' => 'Google Font',
        '2' => 'loli.net(GoogleFont 镜像)',
        '3' => '自定义 (在下一个设置项填写)'
    ),'1',_t('字体 CDN'),_t('使用第三方字体 CDN，在博客愉快地使用思源宋体/黑体，若关闭则使用系统默认的字体'));
    $form->addInput($fontCDN);
    $fontCustom = new Text("fontCustom", NULL, NULL, "自定义字体 CDN","在这里写入引入字体文件的 css 文件 url，文件内应包含「思源宋体」和「思源黑体」的引用，不能直接写入字体文件 url！！！<br>
    <strong>字体 css 文件内应使用 <code>@font-face</code> 来引入思源宋体/黑体字体源文件，参见 Google Font 提供的 css 文件</strong>");
    $form->addInput($fontCustom);

    $gravatarCDN = new Select('gravatarCDN',array(
        '0' => 'www.gravatar.com',
        '1' => 'secure.gravatar.com',
        '2' => 'cn.gravatar.com(国内)',
        '3' => 'V2EX CDN (推荐)',
        '4' => 'loli.net'
    ),'3',_t('Gravatar CDN'),_t('调用 Gravatar 评论头像时使用的 CDN 源'));
    $form->addInput($gravatarCDN);

    //TimThumb
    $default_allowlist_timthumb="'flickr.com',
'staticflickr.com',
'picasa.com',
'img.youtube.com',
'upload.wikimedia.org',
'photobucket.com',
'imgur.com',
'imageshack.us',
'tinypic.com',
'cdn.jsdelivr.net'";
    $timthumbAllowlist = new Textarea("timthumbAllowlist", NULL, $default_allowlist_timthumb, "TimThumb 白名单","当主题处理外部图片的时候会检测来源，请在这里写入你的图床或 CDN 地址，没有请留空<br>注意书写格式，应按照<code>'url', 'url'</code>的格式书写");
    $form->addInput($timthumbAllowlist);

    //Language
    $lang_ = new Text("lang_", NULL, "zh-cn", "多语言","在这里写入语言名以调用对应的语言包，语言包储存在<code>/libs/lang/</code>中，请确保填入的语言名存在对应的语言文件（比如 zh-cn 就对应 zh-cn.php），如果你不明白请保持原设置");
    $form->addInput($lang_);

    //commentSwitch
    $commentSwitch = new Select('commentSwitch',array(
        '0' => '关',
        '1' => '开',
    ),'1',_t('全站评论开关'),_t('选择是否开启评论，在某些特殊情况(例如备案时)可以直接关闭全站的评论功能'));
    $form->addInput($commentSwitch);

    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    /* == /Super == */

    /* == Development == */
    $form->addItem(new Contain('<div class="miracle-panel" miracle-panel="">'));
    $form->addItem(new Title('<i class="iconfont iconkeyboard miracle-item-icon"></i> 开发者设置','Head、Header、Footer、CSS、JavaScript'));

    $headCustom = new Textarea("headCustom", NULL, NULL, "自定义头部（head）","写入 html 代码，输出在 head 标签的最后，通常用于引入 css 文件等");
    $form->addInput($headCustom);
    $headerCustom = new Textarea("headerCustom", NULL, NULL, "自定义页眉（header）","写入 html 代码，输出在 header 标签的最后（body 开始的第一个标签），不常用");
    $form->addInput($headerCustom);
    $footerCustom = new Textarea("footerCustom", NULL, NULL, "自定义页脚信息（Footer Info）","写入 html 代码，输出在页脚的版权信息之后，通常用于写入备案号等信息");
    $form->addInput($footerCustom);
    $footerCodeCustom = new Textarea("footerCodeCustom", NULL, NULL, "自定义页脚（Footer）","写入 html 代码，输出在页面的最后，通常用于引入 js 等");
    $form->addInput($footerCodeCustom);

    $CSSCustom = new Textarea("CSSCustom", NULL, NULL, "自定义 CSS","写入 CSS 代码，输出在 head 标签中的 style 标签里，位于自定义头部之前");
    $form->addInput($CSSCustom);
    $JSCustom = new Textarea("JSCustom", NULL, NULL, "自定义 JavaScript","写入 JS 代码，输出在页面最后的 script 标签中，位于自定义页脚之前");
    $form->addInput($JSCustom);


    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    /* == /development == */

    /* == End == */
    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));
    $form->addItem(new Typecho_Widget_Helper_Layout("/div"));

    $form->addItem(new Typecho_Widget_Helper_Layout('script src="'.Helper::options()->themeUrl.'/assets/libs/jquery/jquery.min.js"></script><script src="'.Helper::options()->themeUrl.'/assets/js/miracle-console.js"></script'));
}