<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * Utils.php
 * 辅助工具
 * 
 * Author:  Eltrac(BigCoke233)
 * License: MIT
 */

class Utils
{
	
    /**
     * 输出相对首页路由，本方法会自适应伪静态，用于动态文件
     */
    public static function index($path = '')
    {
        Helper::options()->index($path);
    }

    /**
     * 输出相对首页路径，本方法用于静态文件
     */
    public static function indexHome($path = '')
    {
        Helper::options()->siteUrl($path);
    }

    /**
     * 输出相对主题目录路径，用于静态文件
     */
    public static function indexTheme($path = '')
    {
        Helper::options()->themeUrl($path);
    }

    /**
     * 判断插件是否可用（存在且已激活）
     */
    public static function hasPlugin($name) 
    {
        $plugins = Typecho_Plugin::export();
        $plugins = $plugins['activated'];
        return is_array($plugins) && array_key_exists($name, $plugins);
    }

    /**
     * 获取 Favicon
     */
    public static function getFavicon() 
    {
        if(Helper::options()->favicon){
            return Helper::options()->favicon;
        }
        else{
            return Helper::options()->themeUrl.'/favicon.ico';
        }
    }

    /**
     * 生成引用
     */
    public static function Require($type, $list, $lib='')
    {
        if($type=="lib-js"||$type=="lib-css") {
            $path='libs/'.$lib.'/';
        }elseif($type=="css"){
            $path='css/';
        }
        elseif($type=="js"){
            $path='js/';
        }
        //输出引用
        if($type=="css"||$type=="lib-css") {
            foreach($list as $file) {
                echo '<link rel="stylesheet" href="'.Helper::options()->themeUrl.'/assets/'.$path.$file.'.css">';
            }
        }
        elseif($type=="js"||$type=="lib-js") {
            foreach($list as $file) {
                echo '<script src="'.Helper::options()->themeUrl.'/assets/'.$path.$file.'.js"></script>';
            }
        }
    }

    /**
     * 博客信息
     */
    public static function blogInfo($type)
    {
        if($type=='name'){
            if(Helper::options()->blogName) return Helper::options()->blogName;
            else return Helper::options()->title;
        }
        elseif($type=='des'){
            if(Helper::options()->blogDes) return Helper::options()->blogDes;
            else return Helper::options()->description;
        }
    }

    /**
     * 懒加载动画
     */
    public static function lazyloadImg($type="post")
    {
        if($type=='link'){
            return Helper::options()->themeUrl.'/assets/img/avatar.jpg';
        }else{
            return Helper::options()->themeUrl.'/assets/img/bilibili.gif';
        }
    }
  
    /**
     * 获取 Gravatar 头像链接
     */
    public static function gravatar($email, int $size = 100, int $CDN = NULL) 
    {
        $CDN = empty($CDN) ? Helper::options()->gravatarCDN : $CDN;
        $email = md5($email);
        if ($CDN == '0') {
            $avatar = 'https://www.gravatar.com/avatar/'.$email.'?s='.$size;
        }elseif ($CDN == '1') {
            $avatar = 'https://secure.gravatar.com/avatar/'.$email.'?s='.$size;
        }elseif ($CDN == '2') {
            $avatar = 'https://cn.gravatar.com/avatar/'.$email.'?s='.$size;
        }elseif ($CDN == '3') {
            $avatar = 'https://cdn.v2ex.com/gravatar/'.$email.'?s='.$size;
        }elseif ($CDN == '4') {
            $avatar = 'https://gravatar.loli.net/avatar/'.$email.'?s='.$size;
        }
        return $avatar;
   }
  
    /**
     * 获取评论者邮箱
     */
    public static function getCommentAvatar($email) 
    {
        $email_hash = md5(strtolower($email));
        $email = strtolower($email);

        return $avatar;
    }

    /**
     * 评论时间输出
     */
    public static function parseCommentDate($created)
    {
        $comment_Y = date('Y', $created);
        if($comment_Y==date('Y')) {
            return date('m-d', $created);
        }
        else {
            return date('Y-m-d', $created);
        }
    }
}