<?php
/**
 * zh-cn.php
 * 中文语言包
 */

$GLOBALS['lang_post']=array(
    'read_more'=>'阅读全文'
);

$GLOBALS['lang_header']=array(
    'category_title'=>'分类'
);

$GLOBALS['lang_archive']=array(
    'archive_title'=>array(
        'category'  =>  '分类 %s 下的文章',
        'search'    =>  '包含关键字 %s 的文章',
        'tag'       =>  '标签 %s 下的文章',
        'author'    =>  '%s 发布的文章'
    ),
    'archive_posts'=>'文章归档',
    'archive_tags'=>'标签云'
);

$GLOBALS['lang_comment']=array(
    'author_tip'=>'博主',
    'deleted'=>'已删除的评论',
    'waiting'=>'正在审核的评论',
    'status_info'=>array(
        'login'=>'这条评论正等待审核',
        'logout'=>'您的评论正在等待审核'
    ),
    //按钮
    'comment_btn'=>'发表评论',
    'reply_btn'=>'<i class="iconfont icon-return"></i>',
    'cancel_btn'=>'取消回复',
    'logout_btn'=>'登出',
    //label
    'login_status_label'=>'欢迎',
    //提示信息
    'closed_info'=>'博主已关闭本页面的评论功能',
    //表单 placeholder
    'name'=>'昵称*',
    'mail'=>'邮箱地址*（将会保密）',
    'url'=>'你的网址（非必须）',
    //评论列表
    'reply_to'=>'回复',
    'comment_list_title'=>'共 %s 条评论'
);