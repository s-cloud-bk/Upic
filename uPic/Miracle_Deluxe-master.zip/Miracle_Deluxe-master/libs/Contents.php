<?php 
/**
 * Contents.php 
 * 内容处理
 * 
 * Author:  Eltrac(BigCoke233)
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
class Contents
{
    /* == 解析文章内容 == */
    /* 为保证兼容性，直接复制 Miracles 1.x 的语法 */
	
    /**
     * 内容解析器入口
     * 传入的是经过 Markdown 解析后的文本
     */
    static public function parseContent($data, $widget, $last)
    {
        $text = empty($last) ? $data : $last;
        if ($widget instanceof Widget_Archive) {
			//ParseOther
			$text = Contents::parseDetails(Contents::parsePicShadow(Contents::parseNotice(Contents::parseKbd(Contents::parseCode(Contents::parseImages(Contents::parseHeadings(Contents::parseTextColor(Contents::parseRuby(Contents::parseTip($text))))))))));
			//LazyLoad
	        $text = preg_replace('/<img (.*?)src(.*?)(\/)?>/','<img $1src="'.'" data-gisrc$2 data-gazeimg />',$text);
			//owo $ links - 因为表情和友情链接的图片需要单独添加懒加载
			$text = Contents::parseLink(Contents::parseEmo($text));
        }
        return $text;
    }
	
	/**
	 *  解析图片
	 */
    static public function parseImages($text)
    {
		//FancyBox & 图题
	    $text = preg_replace('/<img(.*?)src="(.*?)"(.*?)alt="(.*?)"(.*?)>/s','<center><img${1}src="${2}"${3}><span class="post-img-alt">${4}</span></center>',$text); 
		return $text;
    }
	
	/**
	 *  解析 Text-Color
	 */
    static public function parseTextColor($text)
    {
		$text = preg_replace('/\&\{(.*?)\|(.*?)\|(.*?)\}/s','<span style="color:${2};background:${3}">${1}</span>',$text);
		return $text;
	}
	
	/**
	 *  解析 Ruby
	 */
    static public function parseRuby($text)
    {
		$reg = '/\{\{(.*?):(.*?)\}\}/s';
        $rp = '<ruby>${1}<rp>(</rp><rt>${2}</rt><rp>)</rp></ruby>';
        $text = preg_replace($reg,$rp,$text);
		
		return $text;
	}
	
	/**
	 *  解析 Tip
	 */
    static public function parseTip($text)
    {
		//Tip without var
		$text = preg_replace('/\[tip\](.*?)\[\/tip\]/s','<div class="tip"><div class="tip-icon"><i class="iconfont icon-info"></i></div><div class="tip-content">${1}</div></div>',$text);
		//Tip
		$text = preg_replace('/\[tip type="(.*?)"\](.*?)\[\/tip\]/s','<div class="tip ${1}"><div class="tip-icon"><i class="iconfont icon-info"></i></div><div class="tip-content">${2}</div></div>',$text);
        //Tip Group
		$text = preg_replace('/\[tip\-group\](.*?)\[\/tip\-group\]/s','<div class="tip-group">${1}</div>',$text);
		
		return $text;
	}
	
	/**
	 *  解析 Notice
	 */
    static public function parseNotice($text)
    {
		$text = preg_replace('/\[notice\](.*?)\[\/notice\]/s','<div class="notice" role="note">${1}</div>',$text);
		return $text;
	}
	
	/**
	 *  图片加阴影
	 */
    static public function parsePicShadow($text)
    {
		$text = preg_replace('/\[shadow\](.*?)\[\/shadow\]/s','<div class="post-img-shadow">${1}</div>',$text);
		return $text;
	}

    /**
     *  解析友链
     */
    static public function parseLink($text)
    {
        //解析友链盒子
        $reg = '/\[links\](.*?)\[\/links\]/s';
        $rp = '<div class="links-box container-fluid"><div class="row">${1}</div></div>';
        $text = preg_replace($reg, $rp, $text);
        //解析友链项目
        $reg = '/\[(.*?)\]\{(.*?)\}\((.*?)\)\+\((.*?)\)/s';
        $rp = '<div class="col-lg-2 col-6 col-md-3 links-container">
		    <a href="${2}" title="${4}" target="_blank" class="links-link">
			  <div class="links-item">
			    <div class="links-img"><img src="'.Utils::lazyloadImg('link').'" data-gisrc=\'${3}\'></div>
				<div class="links-title">
				  <h4>${1}</h4>
				</div>
		      </div>
			  </a>
			</div>';
        $text = preg_replace($reg, $rp, $text);
        //解析外部友链
        $reg = '/\[links data="(.*?)"\]/';
        $dataLink = preg_match_all($reg, $text, $matches);
        if (!$dataLink) return $text; //普通文章别匹配!
        $http = Typecho_Http_Client::get();
        if (false == $http) {
            $text = str_replace($matches[0][0],  '<br>对不起, 您的主机不支持 php-curl 扩展而且没有打开 allow_url_fopen 功能, 无法正常使 json 友链功能', $text);
            return $text;
        }
        for ($j = 0; $j <= $dataLink; $j++) {
            $match = $matches[1][$j];
            try {
                $result = $http->send($match);
            } catch (Typecho_Http_Client_Exception $ex) {
                $text = str_replace($matches[0][$j],  '对不起,json外链请求失败! 错误信息:' . $ex->getMessage(), $text);
                continue;
            }
            $data = json_decode($result, true);
            if ($data == false) {//没获取到数据就别走了!赶紧返回免得搞出事情
                $text = str_replace($matches[0][$j],  '对不起,json外链解析失败!', $text);
                continue;
            }
            $linkItemNum = count($data);
            $linksList = '';//先Define一下,IDE在报错QAQ
            for ($i = 0; $i < $linkItemNum; $i++) {
                $name = $data[$i]['name'];
                $link = $data[$i]['link'];
                $avatar = $data[$i]['avatar'];
                $des = $data[$i]['des'];
                //嵌入列表
                $linksList .= '<div class="col-lg-2 col-6 col-md-3 links-container">
		    <a href="' . $link . '" title="' . $des . '" target="_blank" class="links-link">
			  <div class="links-item">
			    <div class="links-img"><img src="'.Utils::lazyloadImg('link').'" data-gisrc=\''.$avatar.'\'></div>
				<div class="links-title">
				  <h4>' . $name . '</h4>
				</div>
		      </div>
			  </a>
			</div>';
            }
            $text = str_replace($matches[0][$j], '<div class="links-box container-fluid"><div class="row">' . $linksList . '</div></div>', $text);
        }
        return $text;
    }
	
	/**
	 *  解析 owo 表情
	 */
    static public function parseEmo($content) 
    {
		$content = preg_replace_callback('/\:\:\(\s*(呵呵|哈哈|吐舌|太开心|笑眼|花心|小乖|乖|捂嘴笑|滑稽|你懂的|不高兴|怒|汗|黑线|泪|真棒|喷|惊哭|阴险|鄙视|酷|啊|狂汗|what|疑问|酸爽|呀咩爹|委屈|惊讶|睡觉|笑尿|挖鼻|吐|犀利|小红脸|懒得理|勉强|爱心|心碎|玫瑰|礼物|彩虹|太阳|星星月亮|钱币|茶杯|蛋糕|大拇指|胜利|haha|OK|沙发|手纸|香蕉|便便|药丸|红领巾|蜡烛|音乐|灯泡|开心|钱|咦|呼|冷|生气|弱|吐血)\s*\)/is',
        array('Contents', 'parsePaopaoBiaoqingCallback'), $content);
        $content = preg_replace_callback('/\:\@\(\s*(高兴|小怒|脸红|内伤|装大款|赞一个|害羞|汗|吐血倒地|深思|不高兴|无语|亲亲|口水|尴尬|中指|想一想|哭泣|便便|献花|皱眉|傻笑|狂汗|吐|喷水|看不见|鼓掌|阴暗|长草|献黄瓜|邪恶|期待|得意|吐舌|喷血|无所谓|观察|暗地观察|肿包|中枪|大囧|呲牙|抠鼻|不说话|咽气|欢呼|锁眉|蜡烛|坐等|击掌|惊喜|喜极而泣|抽烟|不出所料|愤怒|无奈|黑线|投降|看热闹|扇耳光|小眼睛|中刀)\s*\)/is',
        array('Contents', 'parseAruBiaoqingCallback'), $content);
        $content = preg_replace_callback('/\:\&\(\s*(.*?)\s*\)/is',
        array('Contents', 'parseTweBiaoqingCallback'), $content);

        return $content;
	}
	
	/**
     * 泡泡表情回调函数
     * 
     * @return string
     */
    private static function parsePaopaoBiaoqingCallback($match)
    {
        return '<img class="owo-img" data-gisrc="/usr/themes/Miracles/assets/img/biaoqing/paopao/'. str_replace('%', '', urlencode($match[1])) . '_2x.png">';
    }

    /**
     * 阿鲁表情回调函数
     * 
     * @return string
     */
    private static function parseAruBiaoqingCallback($match)
    {
        return '<img class="owo-img" data-gisrc="/usr/themes/Miracles/assets/img/biaoqing/aru/'. str_replace('%', '', urlencode($match[1])) . '_2x.png">';
    }

    /**
     * 推特表情回调函数
     * 
     * @return string
     */
    private static function parseTweBiaoqingCallback($match)
    {
        return '<img class="owo-img" data-gisrc="/usr/themes/Miracles/assets/img/biaoqing/twemoji/'. str_replace('%', '', $match[1]) . '.png">';
    }
	
	/**
	 * 解析代码块
	 */
    static public function parseCode($text) 
    {
		$text = preg_replace('/<pre><code>/s','<pre><code class="language-html">',$text);
		return $text;
	}
	
	/**
	 * 解析键盘按键
	 */
    static public function parseKbd($text) 
    {
		$text = preg_replace('/\[\[(.*?)\]\]/s','<kbd>${1}</kbd>',$text);
		return $text;
    }
    
    /**
	 * 解析 <details>
	 */
    static public function parseDetails($text) 
    {
        $text = preg_replace('/\[details sum="(.*?)"\](.*?)\[\/details\]/s','<details><summary>${1}</summary>${2}</details>',$text);
        return $text;
    }

    /* == 文章目录 == */

	/**
	 *  解析章节链接
	 */ 
    static public function parseHeadings($text)
    {
		$reg='/\<h([2-3])(.*?)\>(.*?)\<\/h.*?\>/s';
        $text = preg_replace_callback($reg, array('Contents', 'parseHeaderCallback'), $text);
		
		return $text;
	}
	 
	/**
     * 为内容中的标题编号
     */
    static private $CurrentTocID = 0;
    static public function parseHeaderCallback($matchs)
    {
        $id = trim($matchs[3]);
        return '<h'.$matchs[1].$matchs[2].' id="'.$id.'">'.$matchs[3].'</h'.$matchs[1].'>';
    }

    /* == 其他 == */

    /**
     * 输出完备的标题
     */
    public static function title(Widget_Archive $archive) 
    {
        $archive->archiveTitle(array(
            'category'  =>  '分类 %s 下的文章',
            'search'    =>  '包含关键字 %s 的文章',
            'tag'       =>  '标签 %s 下的文章',
            'author'    =>  '%s 发布的文章'
        ), '', ' | ');
        Helper::options()->title();
    }

    /**
     * 输出导航
     */
    public static function Nav($widget, $type='')
    {
        if(Helper::options()->blogName) $name=Helper::options()->blogName;
        else $name=Helper::options()->title;
        $class=''; $capital='<li class="nav-item nav-caption"><a href="'.Helper::options()->siteUrl.'">'.$name.'</a></li>';
        if($type=='mobile'){ $class=' nav-mobile-content'; $capital='';}
        echo '<ul class="nav-content'.$class.'">'.$capital;
        if($type=='mobile') echo '<li class="nav-list-title"><span>PAGES</span></li>';
        if(Helper::options()->navContent){
            $data=json_decode(Helper::options()->navContent);
            foreach($data as $title=>$target){
                if(is_object($target)){
                    //下拉导航
                    $list='';
                    foreach($target as $key=>$val){
                        if(is_array($val)) return false; //不支持二级以后的导航
                        $list.='<li class="dropdown-item"><a href="'.$val.'">'.$key.'</a></li>';
                    }
                    echo '<li class="nav-item dropdown"><span>'.$title.'</span><ul class="dropdown-content">'.$list.'</ul></li>';
                }else{
                    //普通的导航
                    echo '<li class="nav-item"><a href="'.$target.'">'.$title.'</a></li>';
                }
            }
        }else{
            $widget->widget('Widget_Contents_Page_List')
            ->parse('<li class="nav-item"><a href="{permalink}">{title}</a></li>');
            $widget->widget('Widget_Metas_Category_List')->to($category);?>
            <li class="nav-item dropdown"><span><?php echo $GLOBALS['lang_header']['category_title']; ?></span>
            <ul class="dropdown-content">
            <?php while ($category->next()):?><li class="dropdown-item<?php if($widget->is('category', $category->slug)): ?> dropdown-item-current<?php endif; ?>">
<a href="<?php $category->permalink(); ?>" title="<?php $category->name(); ?>"><?php $category->name(); ?></a></li>
            <?php endwhile;?>
            </ul><?php
        }
        echo '</ul>';
    }

    /**
     * 导航小图标
     */
    public static function NavIcons($archive, $type='') 
    {
        $class='';$btn_id_pre='';
        if($type=='mobile') {$class=' nav-mobile-icons';$btn_id_pre='mobile-';}
        if($type!='mobile') echo '<ul class="nav-divider"></ul>';
        echo '<ul class="nav-icons'.$class.'">';
        if(!Helper::options()->navIcons){
            echo '<li class="nav-icon"><button id="'.$btn_id_pre.'dark-mode-btn"><i class="iconfont icon-sun"></i></button></li>';
            echo '<li class="nav-icon"><button id="'.$btn_id_pre.'admin-btn"><i class="iconfont icon-user"></i></button></li>';
            echo '<li class="nav-icon"><button id="'.$btn_id_pre.'search-btn"><i class="iconfont icon-chaxun"></i></button></li>';
        }
        echo '</ul>';
    }

    /**
     * 输出文章缩略图
     */
    public static function postBanner($post)
    {
        if($post->fields->banner){
            echo $post->fields->banner;
        }
        elseif($post->fields->thumb){
            echo $post->fields->thumb;
        }
        else{
            echo Helper::options()->themeUrl.'/assets/img/postbg/'.mt_rand(1,mt_rand(1,mt_rand(1,mt_rand(1,15)))).'.jpg';
        }
    }

    /**
     * 输出页脚内容
     */
    public static function footer($archive)
    {   
        //author
        $author=Helper::options()->title;
        if(Helper::options()->blogAuthor){
            $author=Helper::options()->blogAuthor;
        }
        //copy info
        $sys_copy='<p id="system-copyright">Powered by Typecho, theme <a href="https://www.miracles.pro/">Miracle!</a> by <a href="https://guhub.cn/">Eltrac</a></p>';
        $site_copy='<p id="copyright">&copy; Copyright '.date('Y').' <a href="'.Helper::options()->siteUrl.'">'.$author.'</a>, All rights reserved.</p>';

        $copy=$sys_copy.$site_copy;
        echo $copy;

        Helper::options()->footerCustom();
    }

    /**
     * 压缩 HTML
     * thanks https://www.jiangxu.site/concerning-how-to-typecho-integrated-html-compression.html
     */
    public static function compressHtml($html_source) 
    {
        $chunks = preg_split('/(<!--<nocompress>-->.*?<!--<\/nocompress>-->|<nocompress>.*?<\/nocompress>|<pre.*?\/pre>|<textarea.*?\/textarea>|<script.*?\/script>)/msi', $html_source, -1, PREG_SPLIT_DELIM_CAPTURE);
        $compress = '';
        foreach ($chunks as $c) {
            if (strtolower(substr($c, 0, 19)) == '<!--<nocompress>-->') {
                $c = substr($c, 19, strlen($c) - 19 - 20);
                $compress .= $c;
                continue;
            } else if (strtolower(substr($c, 0, 12)) == '<nocompress>') {
                $c = substr($c, 12, strlen($c) - 12 - 13);
                $compress .= $c;
                continue;
            } else if (strtolower(substr($c, 0, 4)) == '<pre' || strtolower(substr($c, 0, 9)) == '<textarea') {
                $compress .= $c;
                continue;
            } else if (strtolower(substr($c, 0, 7)) == '<script' && strpos($c, '//') != false && (strpos($c, "\r") !== false || strpos($c, "\n") !== false)) {
                $tmps = preg_split('/(\r|\n)/ms', $c, -1, PREG_SPLIT_NO_EMPTY);
                $c = '';
                foreach ($tmps as $tmp) {
                    if (strpos($tmp, '//') !== false) {
                        if (substr(trim($tmp), 0, 2) == '//') {
                            continue;
                        }
                        $chars = preg_split('//', $tmp, -1, PREG_SPLIT_NO_EMPTY);
                        $is_quot = $is_apos = false;
                        foreach ($chars as $key => $char) {
                            if ($char == '"' && $chars[$key - 1] != '\\' && !$is_apos) {
                                $is_quot = !$is_quot;
                            } else if ($char == '\'' && $chars[$key - 1] != '\\' && !$is_quot) {
                                $is_apos = !$is_apos;
                            } else if ($char == '/' && $chars[$key + 1] == '/' && !$is_quot && !$is_apos) {
                                $tmp = substr($tmp, 0, $key);
                                break;
                            }
                        }
                    }
                    $c .= $tmp;
                }
            }
            $c = preg_replace('/[\\n\\r\\t]+/', ' ', $c);
            $c = preg_replace('/\\s{2,}/', ' ', $c);
            $c = preg_replace('/>\\s</', '> <', $c);
            $c = preg_replace('/\\/\\*.*?\\*\\//i', '', $c);
            $c = preg_replace('/<!--[^!]*-->/', '', $c);
            $compress .= $c;
        }
        return $compress;
    }

    /**
    * 文章归档
    */
    public static function archives($widget) {
        $db = Typecho_Db::get();
        $rows = $db->fetchAll($db->select()
        ->from('table.contents')
         ->order('table.contents.created', Typecho_Db::SORT_DESC)
        ->where('table.contents.type = ?', 'post')
        ->where('table.contents.status = ?', 'publish'));
          
        $stat = array();
        foreach ($rows as $row) {
            $row = $widget->filter($row);
            $arr = array(
                'title' => $row['title'],
                'permalink' => $row['permalink']
            );
            $stat[date('Y', $row['created'])][$row['created']] = $arr;
        }
        return $stat;
    }

}