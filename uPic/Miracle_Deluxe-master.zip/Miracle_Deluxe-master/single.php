<?php
/**
 * 文章页面和独立页面 默认模板
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('includes/head.php');
$this->need('includes/header.php');
$this->need('includes/main.php');
$this->need('includes/footer.php'); 