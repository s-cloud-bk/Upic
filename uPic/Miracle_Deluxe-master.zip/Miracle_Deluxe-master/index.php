<?php
/**
 * We can find a Miracle! 我们能引发奇迹
 * 欢迎使用「Miracle!」主题，通过<a href="https://docs.miracles.pro">这个链接</a>获取有关主题的帮助。
 * 
 * @package Miracles
 * @author  Eltrac Koalar
 * @version 2.0.0
 * @link    https://guhub.cn
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('includes/head.php');
$this->need('includes/header.php');
$this->need('includes/post-list.php');
$this->need('includes/footer.php');