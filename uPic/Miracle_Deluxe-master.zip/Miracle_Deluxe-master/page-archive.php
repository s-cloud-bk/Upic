<?php
/**
 * 归档页面
 *
 * @package custom
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$_SESSION['archive']=true;
$this->need('includes/head.php');
$this->need('includes/header.php');
?>
<div class="main-container">
  <div class="post-body">
    <div class="post-content textretty tex-title-no-line">
    <!-- 标签云 -->
    <?php $this->widget('Widget_Metas_Tag_Cloud', 'sort=mid&ignoreZeroCount=1&desc=0&limit=30')->to($tags); ?>
      <h2><?php gtecho('lang_archive','archive_tags'); ?></h2>
      <?php if($tags->have()): ?>
      <ul class="tags-list">
        <?php while ($tags->next()): ?>
        <li class="tags-item"><a href="<?php $tags->permalink(); ?>" rel="tag" class="no-line" title="有 <?php $tags->count(); ?> 篇文章在这个标签下"><?php $tags->name(); ?></a></li>
        <?php endwhile; ?>
      </ul>
      <?php else: ?>
      <p>这个博主没有写过标签</p>
      <?php endif; ?>
    <!-- 文章归档 -->
    <?php $this->widget('Widget_Metas_Category_List')->to($category); ?>
	 <h2><?php gtecho('lang_archive','archive_posts'); ?></h2>
	  <ul class="archives-list"><?php
      $archives = Contents::archives($this);
      $number = 0;
      foreach($archives as $year => $posts) {
       $detailsOpen = ($number === 0) ? ' open' : NULL;
       echo '<details'.$detailsOpen.'>';
       echo '<summary>'.$year.' '.gt('archivePageTexts','archiveTimeYear').'<small class="archives-count">'.gta('archivePageTexts','archiveYearTotal',count($posts)).'</small></summary>';
        foreach($posts as $created => $post) {
         echo '<li><a href="'.$post['permalink'].'" class="no-line">
          <span class="archives-date">'.date('m-d', $created).'</span>
          '.$post['title'].'
        </a></li>';
        }
       echo '</details>';
       $number++;
      }?>
	  </ul>
    </div>
  </div>
</div>
<?php
$this->need('includes/footer.php'); 