![](screenshot.jpg)

> 感谢您支持 Miracle! 主题！| Screenshot 原图：[pixiv.83941944](https://www.pixiv.net/artworks/83941944)

这是 Miracle! 主题豪华版用户获取最新源代码的仓库，这个仓库将会实时更新，有 bug 或意见可以在 issues 里提出。由于仓库里的源代码是实时更新的，可能具有不稳定性，若需使用请查看最后一个 commit 是否标注了「不稳定」，若没有再下载使用。

仓库里的主题文件请不要传播、分发、倒卖，付费豪华版用户自己使用请随意。
