<?php
/**
 * 404 错误页面
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('includes/head.php');
?>
<!DOCTYPE html>
<html lang="<?php $this->options->lang_(); ?>">
  <head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="renderer" content="webkit">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title><?php Contents::title($this); ?></title>
    <!-- Favicon -->
    <link rel="icon" href="<?php echo Utils::getFavicon(); ?>">
    <!-- Font -->
    <?php if($this->options->fontCDN!='0'): ?><link rel="stylesheet" href="<?php 
      if($this->options->fontCDN=='2'): $theme_font_url = "https://fonts.loli.net/css?family=Alata&display=swap";
      else: $theme_font_url = "https://fonts.googleapis.com/css2?family=Alata&display=swap";
      endif;
      echo $theme_font_url;
     ?>" /><?php endif; ?><!-- Font CDN -->
    <!-- css -->
    <?php Utils::Require('css', array('miracle-404')); ?>
    <!-- 其他 -->
    <?php $this->header('generator=&pingback=&xmlrpc=&wlw=&commentReply=&description=&antiSpam='); ?>
  </head>
  <body>
    <main class="page-404">
      <h1 class="page-404-title">
        <span id="c1">4</span>
        <span id="c2">0</span>
        <span id="c3">4</span>
      </h1>
      <p>啊这，页面没了啊</p>
      <p><a class="page-404-home" href="<?php $this->options->siteUrl(); ?>">回到首页</a></p>
    </main>
  </body>
</html>