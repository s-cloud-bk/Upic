/**
 * ___  ____                _      _ 
 * |  \/  (_)              | |    | |
 * | .  . |_ _ __ __ _  ___| | ___| |
 * | |\/| | | '__/ _` |/ __| |/ _ \ |
 * | |  | | | | | (_| | (__| |  __/_|
 * \_|  |_/_|_|  \__,_|\___|_|\___(_)
 * 
 * Miracle-lib.js
 * 前端库
 */

/**
 * 辅助工具
 */

var Utils = {}

/* localStorage */

Utils.store = function(key, name){
    localStorage.setItem(key, name);
}

Utils.claim = function(key){
    return localStorage.getItem(key);
}

Utils.destroy = function(key){
    localStorage.setItem(key, null);
}

/**
 * 动画 & 功能
 */

var miracle = {}

/* Animation */

miracle.scaleIn = function(object, time) {
    object.css('transition', time).css('transform', 'scale(0)');
    object.show();
    object.css('transform', 'scale(1)');
}

miracle.scaleOut = function(object, time) {
    object.css('transition', time).css('transform', 'scale(0)')
}

/* GoTop Func */

miracle.GoTop = function() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}

/* OwO Loader */

miracle.owoLoad = function() {
    if($(".OwO").length>0){
      var OwO_demo = new OwO({
          logo: 'OωO',
          container: document.getElementsByClassName('OwO')[0],
          target: document.getElementsByClassName('OwO-textarea')[0],
          api: owoJson,
          position: 'down',
          width: '400px',
          maxHeight: '250px'
      });
    }
}

/* Link Target (_blank) */

miracle.linkTarget = function() {
    var all_a = document.getElementsByTagName("a");
    host_url=window.location.host;
    for (var i = 0; i < all_a.length; i++) {
        var domain = all_a[i].href.split("/"); //以“/”进行分割
        if (domain[2]!=host_url) {
            all_a[i].target = "_blank";
        }
    }
}

/* Pangu.js Loader */

miracle.panguSpacing = function() {
    document.addEventListener('DOMContentLoaded', () => {
        pangu.autoSpacingPage();
    });
}

/* Highlight Loader */

miracle.highlight = function() {
    $(document).ready(function() {
        $('pre code').each(function(i, block) {
            hljs.highlightBlock(block);
            hljs.lineNumbersBlock(block, {
                singleLine: true
            });
        })
    });
}

/* Mark comment parent */

miracle.markCommentParent = function(){
    $(document).ready(function(){
        $(".comment-reply-at").on("click", function(e){
            e.preventDefault();
            target_id=$(this).attr('href');
            console.log(target_id);
            $('.comments-content-wrap').removeClass('comment-reply-targeted');
            $(target_id+' .comments-content-wrap').toggleClass('comment-reply-targeted');
        });
        $('.comments-content-wrap').click(function(){
            $(this).removeClass('comment-reply-targeted');
        })
    });
}

/* Dark Mode */

miracle.DarkListen = function(){
    $(document).ready(function(){
        /* 取出 localStorage 和系统偏好颜色 & 判断日间/夜间 */
        let prefersDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (prefersDarkMode){
            if(Utils.claim('miracle_theme')=='light'){
                miracle.DarkOff();
                notyf.success('无视系统设置，开启日间模式');
            }
            else{
                miracle.DarkOn();
                notyf.success('已自动切换夜间模式');
            }
        }
        else if (Utils.claim('miracle_theme')=='dark') {
            miracle.DarkOn();
            notyf.success('已自动切换夜间模式');
        }
        /* 监听系统偏好颜色切换 */
        let media = window.matchMedia('(prefers-color-scheme: dark)');
        if (typeof media.addEventListener === 'function') {
            media.addEventListener('change', function(){
                let prefersDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
                miracle.DarkToggle(true, prefersDarkMode)
            });
        }else if (typeof media.addListener === 'function') {
            media.addListener(function(){
                let prefersDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
                miracle.DarkToggle(true, prefersDarkMode)
            });
        }
        /* 绑定按钮 */
        $('#dark-mode-btn, #mobile-dark-mode-btn').click(function(){
            if(!$('body').hasClass('theme-dark')){
                miracle.DarkOn();
                notyf.success('已切换夜间模式');
                Utils.store('miracle_theme', 'dark');
            }else{
                miracle.DarkOff();
                notyf.success('已切换日间模式');
                Utils.store('miracle_theme', 'light');
            }
        });
    });
}

miracle.DarkOn = function(){
    $('body').addClass('theme-dark');
    $('#dark-mode-btn .iconfont, #mobile-dark-mode-btn .iconfont').removeClass('icon-sun');
    $('#dark-mode-btn .iconfont, #mobile-dark-mode-btn .iconfont').addClass('icon-moon');
    $('.banner-mask.no-bg a').css('color', '#fff');
}

miracle.DarkOff = function(){
    $('body').removeClass('theme-dark');
    $('#dark-mode-btn .iconfont, #mobile-dark-mode-btn .iconfont').addClass('icon-sun');
    $('#dark-mode-btn .iconfont, #mobile-dark-mode-btn .iconfont').removeClass('icon-moon');
    $('.banner-mask.no-bg a').css('color', '#000');
}

miracle.DarkToggle = function(auto, dark=false){
    if(!auto){
        if(!$('body').hasClass('theme-dark')){
            miracle.DarkOn();
            notyf.success('已切换夜间模式');
        }else{
            miracle.DarkOff();
            notyf.success('已切换日间模式');
        }
    }else{
        if(dark){
            miracle.DarkOn();
            notyf.success('已自动切换夜间模式');
            if(Utils.claim('miracle_theme')=='light') Utils.destroy('miracle_theme');
        }else{
            miracle.DarkOff();
            notyf.success('已自动切换日间模式');
            if(Utils.claim('miracle_theme')=='dark') Utils.destroy('miracle_theme');
        }
    }
}

/* Nav mobile open */

miracle.NavToggleListen = function(){
    $(document).ready(function(){
        $('#nav-mobile-open').click(function(){
            $('.nav-mobile-panel').toggleClass('hidden');
            if($('.nav-mobile-panel').hasClass('hidden')){
                $('html').removeClass('no-scroll');
            }else{
                $('html').addClass('no-scroll');
            }
        });
        $('#nav-mobile-more').click(function(){
            $('.nav-mobile-bar').toggleClass('hidden');
        });
        $('.nav-mobile-panel a, .nav-mobile-capital a').click(function(){
            $('.nav-mobile-panel').addClass('hidden');
            if($('.nav-mobile-panel').hasClass('hidden')){
                $('html').removeClass('no-scroll');
            }else{
                $('html').addClass('no-scroll');
            }
        })
    });
}

/* Admin button */

miracle.adminBtn = function(){
    $(document).ready(function(){
        $('#admin-btn, #mobile-admin-btn').click(function(){
            window.open(__TYPECHO_ADMIN_DIR__);
        })
    })
}

/* search button */

miracle.searchBtn = function(){
    $(document).ready(function(){
        $('#search-btn').click(function(){
            $('.nav-search').toggleClass('hidden');
        });
        $('#mobile-search-btn').click(function(){
            $('.nav-search, .nav-mobile-bar').toggleClass('hidden');
        });
        $('#nav-search-close').click(function(e){
            e.preventDefault();
            $('.nav-search').addClass('hidden');
        })
    })
}


/* |===============================| */

/**
 * 评论
 */

var miracleComment = {}

var replyTo = '';
miracleComment.bindButton = function() {
    //绑定“评论回复”和“取消回复”的事件
    $(".comments-reply a").click(
        function () {
            replyTo = $(this).parent().parent().parent().parent().parent().attr("id");
            console.log(replyTo);
        }
    );
    $(".cancel-comment-reply a").click(function () { replyTo = ''; });
}

miracleComment.counts = function(){
    //显示在评论区的评论数加一
    var cmt_counts = parseInt($('#response span').text())+1;
    $('#response span').text(cmt_counts.toString());
}

miracleComment.before = function(){
    $("#comment-form input,#comment-form textarea").attr('disabled', true).css('cursor', 'not-allowed');
}

miracleComment.after = function(ok){
    $("#comment-form input,#comment-form textarea").attr('disabled', false).css('cursor', 'pointer');
    if(ok){
        $("#textarea").val('');
        replyTo = '';
    }
}

miracleComment.core = function() {
 $('#comment-form').submit(function() {
    //监听评论表单submit事件
    var commentData = $(this).serializeArray(); //获取表单POST的数据
    miracleComment.before();
    $.ajax({
        type: $(this).attr('method'),
        url: $(this).attr('action'),
        data: commentData,
        error: function(e) {
            notyf.error('发送 AJAX 请求时失败，请尝试刷新页面！');
        },
        success: function(data) {
            /* 评论失败提示 */
            if (!$('#comments', data).length) {
                var msg = $('title').eq(0).text().trim().toLowerCase() === 'error' ? $('.container', data).eq(0).text() : '评论提交失败！';
                notyf.error(msg);
                miracleComment.after(false);
                return false;
            }
            /* 若发送成功 */
            var newComment; //新的评论的元素html内容
            var Obj = $(document.createElement('body')).append(data);
            if ($(Obj)[0].querySelector('.container') == null) {
                var htmlData = $(document.createElement('body')).append(data);
                //新评论ID
                if (htmlData.html()) {
                    try {
                        newCommentId = htmlData.html().match(/id=\"?comment-\d+/g).join().match(/\d+/g).sort(function (a, b) { return a - b }).pop();
                    }
                    catch(error) {
                        notyf.error('获取评论 ID 时失败，请尝试刷新');
                        console.error(error);
                    }
                }else{
                    notyf.error('获取评论 ID 时发生错误，请尝试刷新');
                    return false;
                }
            };
            if( '' === replyTo ) {//处理父级评论
                if(!$('.comments-list').length) {
                    //如果没有评论列表结构，直接把传过来的 html 塞进去
                    newComment  = $("#comment-" + newCommentId, data);
                    $('.comment-box').after($(Obj)[0].querySelector('.comment-list-body'));
                }
                else if($('.prev').length) {
                    //如果评论页面不在第一页，直接跳转到第一页
                    $('.comments-pagenav li a').eq(1).click();
                }
                else {
                    //当前评论在第一页，把新评论插入到评论列表中
                    newComment  = $("#comment-" + newCommentId, data);
                    $('.comments-list').first().prepend((newComment).addClass('animated fadeInUp'));
                }
                //一些处理
                $('html,body').animate({scrollTop:$('#response')}, 1000);
            }
            else {
                newComment = $("#comment-" + newCommentId, data);
                //处理子级评论
                if($('#' + replyTo).hasClass('comment-parent')){
                    if ($('#' + replyTo).find('.comment-children').length) {//当前父评论已经有嵌套的结构
                        $('#' + replyTo + ' .comment-children .comment-list').first().prepend((newComment).addClass('animated fadeInUp'));
                        TypechoComment.cancelReply();
                    }
                    else {//当前父评论没有嵌套的结构
                        $('#' + replyTo).append('<div class="comment-children"><div class="comments-list"></div></div>');
                        $('#' + replyTo + ' .comment-children .comments-list').first().prepend((newComment).addClass('animated fadeInUp'));
                        TypechoComment.cancelReply();
                    }
                }else{
                    $('#' + replyTo).after((newComment).addClass('animated fadeInUp'));
                }
            }
            miracleComment.counts();//评论+1
            miracleComment.after(true);
            notyf.success('评论提交成功!');//评论成功提示
        }
    });
    return false;
 });
}