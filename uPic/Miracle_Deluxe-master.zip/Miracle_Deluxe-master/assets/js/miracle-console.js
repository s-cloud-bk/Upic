/**
 * Console
 * 后台设置 js
 */

$(".miracle-panel-item-header").on("click", function(){
    $(this).next(".miracle-panel-item-body:not(.miracle-panel-item-body .miracle-panel-item-body)").toggleClass("open");
});

$("#open-all").on("click", function(){
    $(".miracle-panel-item-body:not(.miracle-panel-item-body .miracle-panel-item-body)").addClass('open');
})

$("#close-all").on("click", function(){
    $(".miracle-panel-item-body:not(.miracle-panel-item-body .miracle-panel-item-body)").removeClass('open');
})