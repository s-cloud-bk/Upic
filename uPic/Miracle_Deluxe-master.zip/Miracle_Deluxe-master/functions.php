<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * ___  ____                _      _ 
 * |  \/  (_)              | |    | |
 * | .  . |_ _ __ __ _  ___| | ___| |
 * | |\/| | | '__/ _` |/ __| |/ _ \ |
 * | |  | | | | | (_| | (__| |  __/_|
 * \_|  |_/_|_|  \__,_|\___|_|\___(_)
 * 
 * Miracle! 核心文件
 */

/* 开源库 */
//none
/* Miracle! 核心 */
require_once('libs/Language.php');//多语言
require_once('libs/Utils.php');//辅助工具
require_once('libs/Contents.php');//内容处理
require_once('libs/Function.php');//功能
require_once('libs/Comments.php');//评论

/**
 * 主题常量
 */

$info = Typecho_Plugin::parseInfo(__DIR__ . '/index.php');
define('_THEME_VERSION_', $info['version']);

/**
 * 注册文章解析 hook
 */

Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('Contents','parseContent');
Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('Contents','parseContent');

/**
 * 主题启用时执行的方法
 */
function themeInit($archive) {
    if ($archive->hidden) header('HTTP/1.1 200 OK');//暴力解决访问加密文章会被 pjax 刷新页面的问题
    //Helper::options()->commentsAntiSpam = false; 关闭反垃圾
	Helper::options()->commentsHTMLTagAllowed = '<a href=""> <img src=""> <img src="" class=""> <code> <del>';
    Helper::options()->commentsMaxNestingLevels = '9999';//最大嵌套层数
    Helper::options()->commentsPageDisplay = 'first';//强制评论第一页
    Helper::options()->commentsOrder = 'DESC';//将最新的评论展示在前
    Helper::options()->commentsCheckReferer = false;//关闭检查评论来源URL与文章链接是否一致判断(否则会无法评论)
    //将设置存入全局变量
    $GLOBALS['TimThumb_allowlist']='{'.Helper::options()->timthumbAllowlist.'}';
    $GLOBALS['lang']=Helper::options()->lang_;
}

/**
 * 构造设置表单
 */

require_once('libs/console/Config.php');

/**
 * 文章自定义字段
 */
function themeFields(Typecho_Widget_Helper_Layout $layout) {
    $banner = new Typecho_Widget_Helper_Form_Element_Text('banner', NULL, NULL,_t('文章头图'), _t('输入一个图片 url，作为缩略图显示在文章列表，没有则不显示'));
    $layout->addItem($banner);
	$excerpt = new Typecho_Widget_Helper_Form_Element_Textarea('excerpt', NULL, NULL,_t('文章摘要'), _t('输入一段文本来自定义摘要，如果为空则自动提取文章前 130 字。'));
    $layout->addItem($excerpt);
	$meta = new Typecho_Widget_Helper_Form_Element_Text('meta', NULL, NULL,_t('元信息'), _t('页面/文章内页会显示该页面的评论数和创建日期（元信息），如果你不需要，可以写一段文字来代替这些内容。'));
    $layout->addItem($meta);
	$commentShow = new Typecho_Widget_Helper_Form_Element_Select('commentShow',array('0'=>'显示','1'=>'隐藏'),'0','是否显示评论列表');
    $layout->addItem($commentShow);
}